import Web3 from 'web3';

// Contract address (replace with your deployed contract address)
const contractAddress = '0xbeacdf706d84ccf78bc7dc264a86bc9051d1333b';
const contractABI = [
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "x",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "y",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "bytes3",
				"name": "color",
				"type": "bytes3"
			}
		],
		"name": "PixelChanged",
		"type": "event"
	},
	{
		"inputs": [],
		"name": "canvasHeight",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "canvasWidth",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "x",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "y",
				"type": "uint256"
			}
		],
		"name": "getPixelColor",
		"outputs": [
			{
				"internalType": "bytes3",
				"name": "",
				"type": "bytes3"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "x",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "y",
				"type": "uint256"
			},
			{
				"internalType": "bytes3",
				"name": "color",
				"type": "bytes3"
			}
		],
		"name": "placePixel",
		"outputs": [],
		"stateMutability": "payable",
		"type": "function"
	}
];


const rectSize = 40;



// METAMASK CONNECT
const connectMetaMaskButton = document.getElementById('connectMetaMask');
let connectedAddress;
let web3MM;

async function connectToMetaMask() {
    if (!window.ethereum) {
        alert('Please install MetaMask to connect');
        return;
    }
    try {
        // Check if MetaMask is connected to Arbitrum One network
        const networkId = await ethereum.request({ method: 'net_version' });
        if (networkId !== '42161') { // Arbitrum One network ID
            alert('Please switch to the Arbitrum One network');
            return;
        }

        // Request account access from MetaMask
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        connectedAddress = accounts[0];
        web3MM = new Web3(window.ethereum);

        contractMM = new web3MM.eth.Contract(contractABI, contractAddress); // Replace with ABI
        console.log('Connected to MetaMask account:', connectedAddress);
        connectMetaMaskButton.innerText = shortenWalletAddress(connectedAddress);
    } catch (error) {
        console.error('Error connecting to MetaMask:', error);
    }
}


function shortenWalletAddress(walletAddress) {

    // Shorten the wallet address
    const prefix = walletAddress.substring(0, 7);
    const suffix = walletAddress.substring(walletAddress.length - 5);
    const stars = '*'.repeat(5);
    const shortenedAddress = prefix + stars + suffix;

    // Return the shortened address
    return shortenedAddress;
}

connectMetaMaskButton.addEventListener('click', connectToMetaMask);








// CANVAS UPDATE

const canvasElement = document.getElementById('pixelCanvas');

const apiKey = process.env.API_KEY;
const infuraUrl = `https://arb-mainnet.g.alchemy.com/v2/${apiKey}`;
console.log(infuraUrl)
const web3Alchemy = new Web3(new Web3.providers.HttpProvider(infuraUrl));
const contractAlchemy = new web3Alchemy.eth.Contract(contractABI, contractAddress); // Replace with ABI

// Function to update a single pixel on the canvas
async function updateCanvasPixel(contract, x, y) {
    const color = await contract.methods.getPixelColor(x, y).call();
    const context = canvasElement.getContext('2d');
    context.fillStyle = convertHexColor(color);
    context.fillRect(x * rectSize, y * rectSize, rectSize, rectSize); // Update pixel based on your canvas dimensions (adjust as needed)
}

// Function to fetch and update the entire canvas based on smart contract data
async function updateCanvas() {
    if (web3MM) {
        console.log("Full")
        // Loop through a reasonable chunk of the canvas (modify based on canvas size)
        for (let x = 0; x < window.innerWidth/rectSize; x++) { // Adjust loop iterations based on your canvas width (1000px / 10px per pixel)
            for (let y = 0; y < window.innerHeight/rectSize; y++) { // Adjust loop iterations based on your canvas height (1000px / 10px per pixel)
            updateCanvasPixel(contractMM, x, y);
            }
        }
    }
}

async function updateCanvasPart() {
    if (web3Alchemy) {
        console.log("Part")
          // Loop through a reasonable chunk of the canvas (modify based on canvas size)
        for (let x = 0; x < 6; x++) { // Adjust loop iterations based on your canvas width (1000px / 10px per pixel)
            for (let y = 0; y < 6; y++) { // Adjust loop iterations based on your canvas height (1000px / 10px per pixel)
            updateCanvasPixel(contractAlchemy, x, y);
            }
        }
    }
}

function convertHexColor(hexColor) {
    // Remove the "0x" prefix if present
    if (hexColor.startsWith("0x")) {
        hexColor = hexColor.slice(2);
    }

    // Add "#" prefix
    return "#" + hexColor;
}

  // Update canvas on initial load and every few seconds (adjust interval as needed)
updateCanvasPart();
setInterval(updateCanvasPart, 5000);

// updateCanvas();
// setInterval(updateCanvas, 5000);





// PALETTE
// Set default color
let selectedColor = "rgb(0, 0, 0)";

// Function to handle color selection
function selectColor(event) {
    let color = event.target.getAttribute('data-color');
    if (color) {
        selectedColor = color;
        updateSelectedColor();
    }
}

// Function to update the selected color appearance
function updateSelectedColor() {
    const colors = document.querySelectorAll('.color');
    colors.forEach(color => {
        color.style.border = '1px solid #ccc'; // Reset border
        if (color.getAttribute('data-color') === selectedColor) {
            color.style.border = '4px solid grey'; // Add additional border to selected color
        }
    });
}

// Add click event listeners to color swatches
const colorSwatches = document.querySelectorAll('.color');
colorSwatches.forEach(color => {
    color.addEventListener('click', selectColor);
});

// Initial update of the selected color appearance
updateSelectedColor();








// CLICK CANVAS

// Get the canvas element
var canvas = document.getElementById('pixelCanvas');
let contractMM;

// Function to handle canvas click event
async function canvasClick(event) {
    // Get the position of the click relative to the canvas

    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    // Calculate the grid position based on the clicked position
    var posX = Math.floor(x / rectSize);
    var posY = Math.floor(y / rectSize);

    console.log(posX, posY, x, y)
    // Display confirmation dialog
    var confirmation = confirm("Do you want to change the square at position (" + posX + ", " + posY + ") to color " + getReadableColorName(selectedColor) + "?");
    if (confirmation) {
        try {
            // Connect to MetaMask using the function
            await connectToMetaMask();

            // Execute the placePixel function of your smart contract
            const color = rgbToHex(selectedColor); // Convert hex color to bytes3 format
            console.log(posX, posY, color)


            contractMM = new web3MM.eth.Contract(contractABI, contractAddress); // Replace with ABI
            await contractMM.methods.placePixel(posX, posY, color)
            .send({
                from: connectedAddress,
                gasLimit: 1500000,
                gasPrice: web3Alchemy.utils.toWei('0.02', 'gwei'),
                value: web3Alchemy.utils.toWei('20', 'gwei')
            })
            .on('transactionHash', (hash) => {
              console.log(`Transaction hash: ${hash}`);
            })
            .on('receipt', (receipt) => {
              console.log(`Pixel placed successfully!`);
            })
            .catch((error) => {
              console.error(`Error placing pixel: ${error}`);
            });

            console.log("Transaction successful:", result);
            // You can add code here to update the canvas if needed
        } catch (error) {
            console.error('Error executing smart contract function:', error);
        }
    }
}

// Function to convert hex color code to color name
function getReadableColorName(rgb) {
    if (rgb === '#000000') {
        return 'Black';
    }

    // Define color mappings
    const colorMap = {
        '255, 255, 255': 'White',
        '0, 0, 0': 'Black',
        '255, 0, 0': 'Red',
        '0, 255, 0': 'Green',
        '0, 0, 255': 'Blue',
        '255, 255, 0': 'Yellow',
        '255, 0, 255': 'Magenta',
        '0, 255, 255': 'Cyan',
        '255, 165, 0': 'Orange'
        // Add more color mappings as needed
    };

    // Convert RGB string to array
    const key = rgb.match(/\d+/g).join(", ");
    return colorMap[key] || "Unknown";
}

// Add click event listener to the canvas
canvas.addEventListener('click', canvasClick);



function rgbToHex(rgb) {
    if (rgb === '#000000') {
        return '0x000000';
    }

    // Define color mappings
    const colorMap = {
        '255, 255, 255': '0xffffff',
        '0, 0, 0': '0x000000',
        '255, 0, 0': '0xff0000',
        '0, 255, 0': '0x00ff00',
        '0, 0, 255': '0x0000ff',
        '255, 255, 0': '0xffff00',
        '255, 0, 255': '0xff00ff',
        '0, 255, 255': '0x00ffff',
        '255, 165, 0': '0xffa500'
        // Add more color mappings as needed
    };

    // Convert RGB string to array
    const key = rgb.match(/\d+/g).join(", ");
    return colorMap[key] || "Unknown";
}

